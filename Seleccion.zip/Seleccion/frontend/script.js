document.getElementById("formulario").addEventListener("submit", async function (e) {
  e.preventDefault();
  const formData = new FormData(this);
  const response = await fetch("http://localhost:3000/api/practicantes", {
    method: "POST",
    body: formData,
  });
  if (response.ok) {
    alert("Tu registro se ha enviado exitosamente.");
    this.reset();
  } else {
    alert("Error.");
  }
});
