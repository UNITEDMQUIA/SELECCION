if (localStorage.getItem("autenticado") !== "true") {
  window.location.href = "login.html";
}
async function cargarPracticantes() {
  const res = await fetch("http://localhost:3000/api/practicantes");
  const data = await res.json();
  const lista = document.getElementById("lista");
  lista.innerHTML = "";
  data.forEach(p => {
    const div = document.createElement("div");
    div.innerHTML = `
      <p><strong>${p.nombre}</strong> - ${p.correo} - ${p.carrera} - Semestre ${p.semestre} - Estado: ${p.estado}</p>
      <a href="http://localhost:3000/uploads/${p.hoja_vida}" target="_blank">Ver Hoja de Vida</a><br/>
      <a href="http://localhost:3000/uploads/${p.hoja_vida}" download>Descargar Hoja de Vida</a>
      <button onclick="actualizarEstado(${p.id}, 'viable')">Viable</button>
      <button onclick="actualizarEstado(${p.id}, 'no viable')">No viable</button>
      <hr/>
    `;
    lista.appendChild(div);
  });
}

async function actualizarEstado(id, estado) {
  await fetch(`http://localhost:3000/api/practicantes/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ estado }),
  });
  cargarPracticantes();
}

function cerrarSesion() {
  localStorage.removeItem("autenticado");
  window.location.href = "login.html";
}

cargarPracticantes();
