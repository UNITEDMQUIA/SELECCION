// backend/server.js
const express = require("express");
const multer = require("multer");
const cors = require("cors");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const fs = require("fs");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

const db = new sqlite3.Database("db.sqlite");
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS practicantes (
    id INTEGER PRIMARY KEY,
    nombre TEXT,
    correo TEXT,
    carrera TEXT,
    semestre INTEGER,
    hoja_vida TEXT,
    estado TEXT DEFAULT 'pendiente'
  )`);
});

const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});
const upload = multer({ storage });

app.post("/api/practicantes", upload.single("hoja_vida"), (req, res) => {  //Registrar un nuevo practicante.
  const { nombre, correo, carrera, semestre } = req.body;
  const hoja_vida = req.file.filename;
  db.run(`INSERT INTO practicantes (nombre, correo, carrera, semestre, hoja_vida) VALUES (?, ?, ?, ?, ?)`,
    [nombre, correo, carrera, semestre, hoja_vida], function (err) {
      if (err) return res.sendStatus(500);
      res.sendStatus(200);
    });
});

app.get("/api/practicantes", (req, res) => {    //Lista los practicantes.
  db.all("SELECT * FROM practicantes", (err, rows) => {
    if (err) return res.sendStatus(500);
    res.json(rows);
  });
});

app.put("/api/practicantes/:id", (req, res) => {      //Actualiza el estado.
  const id = req.params.id;
  const { estado } = req.body;
  db.run("UPDATE practicantes SET estado = ? WHERE id = ?", [estado, id], function (err) {
    if (err) return res.sendStatus(500);
    res.sendStatus(200);
  });
});

app.listen(3000, () => console.log("Servidor backend corriendo en http://localhost:3000"));
